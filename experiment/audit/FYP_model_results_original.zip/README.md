# Hotel Booking Cancellation Prediction – FYP code (Afiq Fakhri bin Yusoff)

This code follows Chapter 3 of the report. It covers cleaning and leakage removal,
a 70/15/15 split, the four models (Logistic Regression, Random Forest, XGBoost and
CatBoost), manual hyperparameter configuration on the validation set, selection by
F1-score, a test-set check of the selected model only, and SHAP explanations.
The random seed is 42 everywhere, and the decision threshold is 0.5.

## How to run (Windows, VS Code)

```
pip install pandas numpy scikit-learn xgboost catboost shap matplotlib joblib
python tune.py simple      # tuning (~45-60 min on a laptop)
python evaluate.py simple  # comparison table, test result, figures, SHAP
```
Put `hotel_bookings.csv` in the same folder. Other versions: replace `simple` with `grouped` or `strict`.

## Results

| Version | Inputs | Repeated records | Best model | Validation F1 | Test F1 | Test AUC |
|---|---|---|---|---|---|---|
| `grouped` | 26 (incl. agent & company IDs) | kept, grouped | XGBoost | 0.8227 | 0.8066 | 0.9381 |
| `simple` | 24 (dashboard-friendly) | kept, grouped | XGBoost | 0.8043 | 0.7973 | 0.9320 |
| `strict` | 26 | removed | Random Forest | 0.7299 | 0.7265 | 0.9088 |

The versions use **different evaluation populations**: strict has 27.5% cancellations, the
others 37%. Their scores are therefore not directly comparable. A gap between them does not
mean one model is better.

## Files

| File | Purpose |
|---|---|
| `prep.py` | Cleaning, leakage removal, splits, preprocessing (fitted on training set only) |
| `tune.py` | Phase 3: manual one-at-a-time hyperparameter configuration (Section 3.4.3) |
| `evaluate.py` | Phase 4: validation comparison, test evaluation, confusion matrices, ROC, SHAP |
| `results_<v>/run_log.txt` | Split sizes, overlap check, seed, and every configuration tried |
| `results_<v>/tuning_log.csv` | Every configuration tried (10–48 per model), with all validation metrics |
| `results_<v>/best_configs.json` | Final hyperparameters for each model |
| `results_<v>/validation_comparison.csv` | Model comparison table (validation set) |
| `results_<v>/validation_predictions.csv` | Validation probabilities for all 4 models (grouped, simple) |
| `results_<v>/test_result_selected.csv` | Test-set metrics, selected model only |
| `results_<v>/test_predictions_selected.csv` | Test probabilities and 0/1 predictions (grouped, simple), for recomputing every metric including AUC |
| `results_<v>/fig_*.png` | Figures for Chapter 4 |

## Preprocessing decisions

- **Invalid records removed (182):** bookings with 0 guests, a negative ADR, or the single ADR outlier (5,400).
- **Outcome leakage removed:** `reservation_status` and `reservation_status_date`.
- **Excluded:** `assigned_room_type` (assigned at check-in) and `booking_changes` (counted
  until check-in or cancellation, so cancelled bookings stop accumulating changes).
- **Excluded:** `arrival_date_year` (2015–2017 only). This avoids an input that cannot take
  new values, but it does **not** by itself show the model works on future bookings.
- **Missing values:** `country` set to "Unknown", `agent`/`company` set to "None" (meaning not
  applicable, per Antonio et al., 2019), `children` filled with the training-set median.
- **Encoding:** one-hot encoding with rare categories (<30 rows) grouped, plus standard scaling,
  for LR, RF and XGBoost. CatBoost uses its built-in categorical handling.
- **Class imbalance:** class-weight hyperparameters, tuned on the validation set.

## Prediction point (important)

Antonio et al. (2019) state that values were taken from the PMS change log relative to the
**day before arrival**. For example, `deposit_type` is derived from payments before arrival or
cancellation, and `adr` from lodging transactions. The inputs therefore describe a booking as
it stands shortly before arrival, **not** at the moment of first confirmation. The prediction
point is: *"cancellation risk for upcoming bookings, using their details up to the day before
arrival."* `days_in_waiting_list` describes waiting before confirmation, so it is available at
that point. `required_car_parking_spaces` and `total_of_special_requests` are the requests
recorded on the booking at that point.

## Repeated (duplicate) records

- The raw file has **31,994** exact duplicate copies; after the cleaning rules there are **31,980**.
- The dataset has no booking identifiers, because they were deleted for anonymity. It is therefore
  an **assumption**, not an established fact, that repeated records are separate bookings (e.g. several
  rooms in one group booking).
- Observed composition of repeated records: 41.6% Groups, 30.4% Offline TA/TO and 20.6% Online TA
  market segment. 35.6% are Non Refund, against 12.2% overall.
- In `grouped` and `simple`, repeated records are kept, but every row with an **identical set of
  final model inputs** (target and removed columns excluded) is put in the same set.
  The overlap check is printed in `run_log.txt` and is **0 / 0 / 0** (train–val, train–test, val–test).
- Without this grouping (a plain random split), a third of validation rows have an identical input
  row in training. The F1-score is then inflated: 0.99 on those rows, and 0.69 on the remaining rows.

## Simplified dashboard inputs (`simple`)

- `agent` ID → **has_agent** (Yes/No) and `company` ID → **has_company** (Yes/No), because the IDs are anonymised.
- `reserved_room_type` dropped (anonymised letter codes), and `distribution_channel` dropped (overlaps `market_segment`).
- In the dashboard, the booking, arrival and departure dates are used to derive lead time, arrival
  month, week number, day of month, weekend nights and weekday nights.

## Disclosure: test-set exposure

- The duplicate policy (`grouped` vs `strict`) was chosen from validation-set analysis, before any
  test score was computed.
- The simplified-input set was proposed **after** the `grouped` test score had been seen. It was
  chosen to make the dashboard usable, and checked on the validation set.
- A first `simple` run grouped on the 26 original inputs instead of the final 24. That allowed 12 test
  rows to have an identical input row in training. It was corrected by grouping on the final inputs,
  which changed the split, and fully retuned. The figures above are from the corrected run only.
- No further changes were made after the corrected test score was seen.

## Interpreting SHAP

SHAP values describe **associations the model has learned**, not causes. For example, "parking
requests are associated with lower predicted cancellation risk" is accurate. "Parking requests
reduce cancellations" is not.
