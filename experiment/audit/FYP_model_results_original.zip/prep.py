"""
Data cleaning and preprocessing for the Hotel Booking Cancellation Prediction FYP.
Follows Chapter 3 (Section 3.3.4) of the report.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42
TARGET = "is_canceled"

# Removed: they reveal the final outcome of the booking (data leakage)
LEAKAGE_COLS = ["reservation_status", "reservation_status_date"]
# Removed: recorded after booking confirmation, so not available when the
# dashboard makes its prediction (Section 3.3.4)
POST_BOOKING_COLS = ["assigned_room_type", "booking_changes"]
# Removed: only covers 2015-2017, so it cannot generalise to future bookings
# entered into the dashboard
NON_GENERALISABLE_COLS = ["arrival_date_year"]

CAT_COLS = [
    "hotel", "arrival_date_month", "meal", "country", "market_segment",
    "distribution_channel", "reserved_room_type", "deposit_type",
    "agent", "company", "customer_type",
]
NUM_COLS = [
    "lead_time", "arrival_date_week_number", "arrival_date_day_of_month",
    "stays_in_weekend_nights", "stays_in_week_nights", "adults", "children",
    "babies", "is_repeated_guest", "previous_cancellations",
    "previous_bookings_not_canceled", "days_in_waiting_list", "adr",
    "required_car_parking_spaces", "total_of_special_requests",
]


def load_and_clean(path, dedup=True, log=print):
    df = pd.read_csv(path)
    log(f"Raw records: {len(df):,} | cancelled: {df[TARGET].mean():.2%}")

    # 1. Duplicate records
    if dedup:
        n = len(df)
        df = df.drop_duplicates()
        log(f"Removed {n - len(df):,} exact duplicate records -> {len(df):,}")

    # 2. Invalid records
    n = len(df)
    guests = df["adults"] + df["children"].fillna(0) + df["babies"]
    df = df[guests > 0]                      # bookings with no guests
    df = df[(df["adr"] >= 0) & (df["adr"] < 5000)]  # negative / extreme ADR
    log(f"Removed {n - len(df):,} invalid records (0 guests, ADR < 0 or ADR outlier) -> {len(df):,}")

    # 3. Leakage and post-booking attributes
    df = df.drop(columns=LEAKAGE_COLS + POST_BOOKING_COLS + NON_GENERALISABLE_COLS)

    # 4. Consistent labels for missing / equivalent categories (rule-based, not learned)
    df["meal"] = df["meal"].replace({"Undefined": "SC"})  # both mean 'no meal package'
    df["country"] = df["country"].fillna("Unknown")
    df["agent"] = df["agent"].fillna("None").astype(str).str.replace(r"\.0$", "", regex=True)
    df["company"] = df["company"].fillna("None").astype(str).str.replace(r"\.0$", "", regex=True)
    for c in CAT_COLS:
        df[c] = df[c].astype(str)

    log(f"Final records: {len(df):,} | cancelled: {df[TARGET].mean():.2%} | predictors: {len(CAT_COLS) + len(NUM_COLS)}")
    return df.reset_index(drop=True)


def split(df):
    """70 / 15 / 15 stratified split."""
    X, y = df[CAT_COLS + NUM_COLS], df[TARGET]
    X_train, X_tmp, y_train, y_tmp = train_test_split(
        X, y, test_size=0.30, stratify=y, random_state=RANDOM_STATE)
    X_val, X_test, y_val, y_test = train_test_split(
        X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=RANDOM_STATE)
    return X_train, X_val, X_test, y_train, y_val, y_test


def split_grouped(df, simple=False):
    """70 / 15 / 15 split that keeps repeated records but puts every row with an
    identical set of MODEL INPUTS (target and removed columns excluded) in the same
    set, so no validation/test row has an identical input row in training.
    Groups are stratified by label and group size."""
    X = to_simple(df[CAT_COLS + NUM_COLS]) if simple else df[CAT_COLS + NUM_COLS]
    key = pd.util.hash_pandas_object(X, index=False).values
    groups = pd.DataFrame({"key": key, "y": df[TARGET].values})
    agg = groups.groupby("key")["y"].agg(["mean", "size"])
    # stratify on label AND group size so large group bookings spread evenly
    size_bin = pd.cut(agg["size"], [0, 1, 3, 10, 30, np.inf], labels=False)
    strata = (agg["mean"] >= 0.5).astype(int).astype(str) + "_" + size_bin.astype(str)
    g_tr, g_tmp = train_test_split(agg.index, test_size=0.30,
                                   stratify=strata.values, random_state=RANDOM_STATE)
    g_va, g_te = train_test_split(g_tmp, test_size=0.50,
                                  stratify=strata.loc[g_tmp].values, random_state=RANDOM_STATE)
    out = []
    for g in (g_tr, g_va, g_te):
        m = np.isin(key, np.asarray(g))
        out.append(m)
    y = df[TARGET]
    (tr, va, te) = out
    return X[tr], X[va], X[te], y[tr], y[va], y[te]


# ---------- Simplified, dashboard-friendly inputs ----------
# agent / company IDs are anonymised numbers a manager cannot know, so they become
# Yes/No questions. reserved_room_type (anonymised letters A-P) and
# distribution_channel (overlaps with market_segment) are dropped.
SIMPLE_CAT = ["hotel", "arrival_date_month", "meal", "country", "market_segment",
              "deposit_type", "customer_type", "has_agent", "has_company"]
SIMPLE_NUM = list(NUM_COLS)


def to_simple(X):
    X = X.copy()
    X["has_agent"] = np.where(X["agent"] == "None", "No", "Yes")
    X["has_company"] = np.where(X["company"] == "None", "No", "Yes")
    return X[SIMPLE_CAT + SIMPLE_NUM]


def make_preprocessor(cat_cols=None, num_cols=None):
    """Fitted on the training set only. Used by LR, RF and XGBoost.
    CatBoost uses its built-in categorical handling instead (Section 2.4.3)."""
    cat_cols = CAT_COLS if cat_cols is None else cat_cols
    num_cols = NUM_COLS if num_cols is None else num_cols
    num = Pipeline([("impute", SimpleImputer(strategy="median")),
                    ("scale", StandardScaler())])
    cat = Pipeline([("impute", SimpleImputer(strategy="constant", fill_value="Unknown")),
                    ("onehot", OneHotEncoder(handle_unknown="infrequent_if_exist",
                                             min_frequency=30, sparse_output=False))])
    return ColumnTransformer([("num", num, num_cols), ("cat", cat, cat_cols)])


def catboost_frame(X, num_median=None):
    """Numeric imputation (median learned from training data) for CatBoost."""
    X = X.copy()
    if num_median is not None:
        cols = list(num_median.index)
        X[cols] = X[cols].fillna(num_median)
    return X
