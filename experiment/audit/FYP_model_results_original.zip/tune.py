"""
Phase 3: model development with manual hyperparameter configuration (Section 3.4.3).
Each hyperparameter in Table 3.4 is changed one at a time from the current best
configuration and evaluated on the validation set. A change is kept only if the
validation F1-score improves. Passes repeat until no change improves the result.

Usage:  python tune.py strict    # duplicates removed, stratified 70/15/15 split
        python tune.py grouped   # duplicates kept, identical copies kept in one set
"""
import sys, json, time, warnings, gc
import numpy as np, pandas as pd, joblib, sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score, precision_score, recall_score
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
import prep

warnings.filterwarnings("ignore")
SCENARIO = sys.argv[1]
DATA = sys.argv[2] if len(sys.argv) > 2 else "hotel_bookings.csv"
OUT = f"results_{SCENARIO}"
import os; os.makedirs(OUT, exist_ok=True)
logf = open(f"{OUT}/run_log.txt", "w")
def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); logf.write(s + "\n"); logf.flush()

# ---------------- data ----------------
df = prep.load_and_clean(DATA, dedup=(SCENARIO == "strict"), log=log)
if SCENARIO == "strict":
    X_train, X_val, X_test, y_train, y_val, y_test = prep.split(df)
else:                               # grouped on the final model inputs
    X_train, X_val, X_test, y_train, y_val, y_test = prep.split_grouped(df, simple=(SCENARIO == "simple"))
CAT, NUM = prep.CAT_COLS, prep.NUM_COLS
if SCENARIO == "simple":            # easier dashboard inputs
    CAT, NUM = prep.SIMPLE_CAT, prep.SIMPLE_NUM
    log(f"Simplified inputs ({len(CAT) + len(NUM)}): {CAT + NUM}")
log(f"Random seed: {prep.RANDOM_STATE} | decision threshold: 0.5 | dedup: {SCENARIO == 'strict'}")
for n, ys in (("train", y_train), ("validation", y_val), ("test", y_test)):
    log(f"{n:<10} {len(ys):>6,} rows ({len(ys)/len(df):.2%}) | cancelled {ys.mean():.2%}")
_h = lambda X: pd.util.hash_pandas_object(X, index=False)
_ktr = set(_h(X_train))
log(f"Overlap check on final inputs: validation rows with identical input row in train = "
    f"{_h(X_val).isin(_ktr).sum()}, test rows = {_h(X_test).isin(_ktr).sum()}, "
    f"test rows identical to a validation row = {_h(X_test).isin(set(_h(X_val))).sum()}")

pre = prep.make_preprocessor(CAT, NUM).fit(X_train)  # fitted on training set only
A_tr, A_va = pre.transform(X_train), pre.transform(X_val)
med = X_train[NUM].median()
C_tr, C_va = prep.catboost_frame(X_train, med), prep.catboost_frame(X_val, med)
log(f"Encoded features for LR / RF / XGBoost: {A_tr.shape[1]}")
spw = float((y_train == 0).sum() / (y_train == 1).sum())
log(f"Negative/positive ratio in training set: {spw:.3f}")

SK_NEW = tuple(int(v) for v in sklearn.__version__.split(".")[:2]) >= (1, 8)

# ---------------- model builders (Table 3.4) ----------------
def build(model, p):
    if model == "Logistic Regression":
        kw = dict(C=p["C"], solver=p["solver"], class_weight=p["class_weight"], max_iter=3000)
        if SK_NEW: kw["l1_ratio"] = 1.0 if p["penalty"] == "l1" else 0.0
        else: kw["penalty"] = p["penalty"]
        return LogisticRegression(**kw)
    if model == "Random Forest":
        return RandomForestClassifier(n_jobs=-1, random_state=prep.RANDOM_STATE, **p)
    if model == "XGBoost":
        q = dict(p); q["scale_pos_weight"] = spw if q["scale_pos_weight"] == "ratio" else q["scale_pos_weight"]
        return XGBClassifier(tree_method="hist", n_jobs=2, random_state=prep.RANDOM_STATE,
                             eval_metric="logloss", **q)
    if model == "CatBoost":
        q = dict(p); cw = q.pop("class_weight")
        return CatBoostClassifier(auto_class_weights=cw, verbose=0, thread_count=2,
                                  random_seed=prep.RANDOM_STATE, **q)

def valid(model, p):
    if model == "Logistic Regression" and p["solver"] == "lbfgs" and p["penalty"] == "l1":
        return False
    return True

def fit_eval(model, p):
    m = build(model, p)
    t = time.time()
    if model == "CatBoost":
        m.fit(C_tr, y_train, cat_features=CAT)
        ptr, pva = m.predict_proba(C_tr)[:, 1], m.predict_proba(C_va)[:, 1]
    else:
        m.fit(A_tr, y_train)
        ptr, pva = m.predict_proba(A_tr)[:, 1], m.predict_proba(A_va)[:, 1]
    yhat = (pva >= 0.5).astype(int)
    r = dict(val_f1=f1_score(y_val, yhat), val_auc=roc_auc_score(y_val, pva),
             val_acc=accuracy_score(y_val, yhat), val_precision=precision_score(y_val, yhat),
             val_recall=recall_score(y_val, yhat), train_f1=f1_score(y_train, ptr >= 0.5),
             seconds=round(time.time() - t, 1))
    return m, r

# ---------------- initial configs and values tried ----------------
SPACE = {
    "Logistic Regression": (
        dict(C=1.0, penalty="l2", solver="lbfgs", class_weight=None),
        dict(C=[0.01, 0.1, 1.0, 10.0], penalty=["l2", "l1"], solver=["lbfgs", "liblinear"],
             class_weight=[None, "balanced"])),
    "Random Forest": (
        dict(n_estimators=200, max_depth=None, min_samples_split=2, min_samples_leaf=1,
             max_features="sqrt", class_weight=None),
        dict(n_estimators=[200, 400], max_depth=[None, 20, 30, 40],
             min_samples_split=[2, 5, 10], min_samples_leaf=[1, 2, 4],
             max_features=["sqrt", "log2", 0.2], class_weight=[None, "balanced", "balanced_subsample"])),
    "XGBoost": (
        dict(n_estimators=300, learning_rate=0.1, max_depth=6, subsample=1.0,
             colsample_bytree=1.0, gamma=0.0, scale_pos_weight=1.0),
        dict(n_estimators=[300, 600, 1000, 1500], learning_rate=[0.03, 0.05, 0.1, 0.2],
             max_depth=[6, 8, 10, 12], subsample=[0.7, 0.8, 1.0], colsample_bytree=[0.5, 0.7, 1.0],
             gamma=[0.0, 0.5, 1.0], scale_pos_weight=[1.0, "ratio", 1.3])),
    "CatBoost": (
        dict(iterations=500, learning_rate=0.1, depth=6, l2_leaf_reg=3.0, class_weight=None),
        dict(iterations=[500, 1000, 1500], learning_rate=[0.05, 0.1, 0.2], depth=[6, 8],
             l2_leaf_reg=[1.0, 3.0, 10.0], class_weight=[None, "SqrtBalanced", "Balanced"])),
}
MAX_PASSES = {"Logistic Regression": 3, "Random Forest": 2, "XGBoost": 3, "CatBoost": 2}

rows, best_all = [], {}
for model, (init, grid) in SPACE.items():
    log(f"\n===== {model} =====")
    seen, step = {}, 0
    def run(p):
        global step
        k = json.dumps(p, sort_keys=True, default=str)
        if k in seen: return None, seen[k]      # already evaluated (never a new best)
        m, r = fit_eval(model, p); step += 1
        rows.append(dict(model=model, step=step, config=k, **r))
        log(f"[{step:02d}] F1={r['val_f1']:.4f} AUC={r['val_auc']:.4f} trainF1={r['train_f1']:.4f} ({r['seconds']}s) {k}")
        seen[k] = r                             # keep scores only, not models (memory)
        return m, r
    best_p = dict(init); best_m, best_r = run(best_p)
    for npass in range(1, MAX_PASSES[model] + 1):
        improved = False
        for param, values in grid.items():
            for v in values:
                if v == best_p[param]: continue
                cand = dict(best_p); cand[param] = v
                if not valid(model, cand): continue
                m, r = run(cand)
                if m is not None and r["val_f1"] > best_r["val_f1"] + 1e-4:
                    best_p, best_m, best_r, improved = cand, m, r, True
                    log(f"     -> kept {param}={v}  (best F1 now {r['val_f1']:.4f})")
                else:
                    del m; gc.collect()
        if not improved:
            log(f"No improvement in pass {npass}; stopping."); break
    log(f"BEST {model}: F1={best_r['val_f1']:.4f} config={best_p}")
    best_all[model] = dict(params=best_p, **best_r)
    joblib.dump(best_m, f"{OUT}/model_{model.replace(' ', '_').lower()}.joblib")

pd.DataFrame(rows).to_csv(f"{OUT}/tuning_log.csv", index=False)
json.dump(best_all, open(f"{OUT}/best_configs.json", "w"), indent=2, default=str)
joblib.dump(dict(pre=pre, num_median=med, spw=spw, cat_cols=CAT, num_cols=NUM), f"{OUT}/preprocessing.joblib")
joblib.dump((X_train, X_val, X_test, y_train, y_val, y_test), f"{OUT}/splits.joblib")
log("\nVALIDATION COMPARISON")
for k, v in sorted(best_all.items(), key=lambda kv: -kv[1]["val_f1"]):
    log(f"{k:<20} F1={v['val_f1']:.4f} AUC={v['val_auc']:.4f} Acc={v['val_acc']:.4f} P={v['val_precision']:.4f} R={v['val_recall']:.4f}")
