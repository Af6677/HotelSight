"""
Phase 4: model evaluation, comparison and SHAP explainability (Section 3.5).
- Compares the four tuned models on the VALIDATION set (Accuracy, Precision,
  Recall, F1, AUC, confusion matrix). Selection is by F1-score.
- Evaluates ONLY the selected model on the untouched TEST set.
- Produces global (summary) and local (waterfall) SHAP explanations.

Usage:  python evaluate.py grouped    (or strict)
"""
import sys, json, warnings
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import shap
from sklearn.metrics import (f1_score, roc_auc_score, accuracy_score, precision_score,
                             recall_score, confusion_matrix, roc_curve)
import prep

warnings.filterwarnings("ignore")
SCENARIO = sys.argv[1]
OUT = f"results_{SCENARIO}"
best = json.load(open(f"{OUT}/best_configs.json"))
pp = joblib.load(f"{OUT}/preprocessing.joblib")
X_train, X_val, X_test, y_train, y_val, y_test = joblib.load(f"{OUT}/splits.joblib")
pre, med = pp["pre"], pp["num_median"]
CAT = pp.get("cat_cols", prep.CAT_COLS); NUM = pp.get("num_cols", prep.NUM_COLS)
MODELS = ["Logistic Regression", "Random Forest", "XGBoost", "CatBoost"]
fname = lambda m: f"{OUT}/model_{m.replace(' ', '_').lower()}.joblib"

def inputs(model, X):
    return prep.catboost_frame(X, med) if model == "CatBoost" else pre.transform(X)

def metrics(y, p):
    yhat = (p >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, yhat).ravel()
    return {"Accuracy": accuracy_score(y, yhat), "Precision": precision_score(y, yhat),
            "Recall": recall_score(y, yhat), "F1-score": f1_score(y, yhat),
            "AUC": roc_auc_score(y, p), "TP": tp, "TN": tn, "FP": fp, "FN": fn}

# ---------- validation comparison ----------
models, val_prob, rows = {}, {}, []
for m in MODELS:
    models[m] = joblib.load(fname(m))
    val_prob[m] = models[m].predict_proba(inputs(m, X_val))[:, 1]
    rows.append({"Model": m, **metrics(y_val, val_prob[m])})
val_tbl = pd.DataFrame(rows).sort_values("F1-score", ascending=False)
val_tbl.to_csv(f"{OUT}/validation_comparison.csv", index=False)
selected = val_tbl.iloc[0]["Model"]
print("VALIDATION SET COMPARISON (selection by F1-score)")
print(val_tbl.round(4).to_string(index=False))
print(f"\nSelected model: {selected}")

# ---------- test set: selected model only ----------
test_prob = models[selected].predict_proba(inputs(selected, X_test))[:, 1]
test_m = metrics(y_test, test_prob)
pd.DataFrame([{"Model": selected, **test_m}]).to_csv(f"{OUT}/test_result_selected.csv", index=False)
# saved predictions so anyone can recompute every metric (including AUC) independently
pd.DataFrame({"row_id": X_val.index, "actual": y_val.values,
              **{f"prob_{m.replace(' ', '_').lower()}": val_prob[m] for m in MODELS}}
             ).to_csv(f"{OUT}/validation_predictions.csv", index=False)
pd.DataFrame({"row_id": X_test.index, "actual": y_test.values, "probability": test_prob,
              "predicted": (test_prob >= 0.5).astype(int)}
             ).to_csv(f"{OUT}/test_predictions_selected.csv", index=False)
print(f"\nTEST SET ({selected}):", {k: (round(v, 4) if isinstance(v, float) else int(v)) for k, v in test_m.items()})

# ---------- figures ----------
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 4, figsize=(16, 3.8))
for ax, m in zip(axes, MODELS):
    cm = confusion_matrix(y_val, (val_prob[m] >= 0.5).astype(int))
    ax.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax.text(j, i, f"{v:,}", ha="center", va="center", color="white" if v > cm.max() / 2 else "black")
    ax.set_xticks([0, 1], ["Not cancelled", "Cancelled"]); ax.set_yticks([0, 1], ["Not cancelled", "Cancelled"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual" if m == MODELS[0] else "")
    ax.set_title(f"{m}\nF1 = {f1_score(y_val, val_prob[m] >= 0.5):.4f}")
fig.suptitle("Confusion matrices on the validation set", y=1.04); fig.tight_layout()
fig.savefig(f"{OUT}/fig_confusion_matrices_validation.png", dpi=200, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(5.5, 5))
for m in MODELS:
    fpr, tpr, _ = roc_curve(y_val, val_prob[m])
    ax.plot(fpr, tpr, label=f"{m} (AUC = {roc_auc_score(y_val, val_prob[m]):.3f})")
ax.plot([0, 1], [0, 1], "--", color="grey", lw=1)
ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
ax.set_title("ROC curves on the validation set"); ax.legend(loc="lower right", frameon=False)
fig.savefig(f"{OUT}/fig_roc_validation.png", dpi=200, bbox_inches="tight"); plt.close(fig)

fig, ax = plt.subplots(figsize=(9, 4))
mets = ["Accuracy", "Precision", "Recall", "F1-score", "AUC"]
w = 0.2
for i, m in enumerate(MODELS):
    vals = val_tbl.set_index("Model").loc[m, mets].values.astype(float)
    bars = ax.bar(np.arange(len(mets)) + (i - 1.5) * w, vals, w, label=m)
ax.set_xticks(range(len(mets)), mets); ax.set_ylim(0.5, 1.0); ax.set_ylabel("Score")
ax.axhline(0.8, color="grey", ls=":", lw=1)
ax.set_title("Model comparison on the validation set"); ax.legend(ncol=4, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.12))
fig.savefig(f"{OUT}/fig_model_comparison.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- SHAP (selected model, test set) ----------
rng = np.random.RandomState(prep.RANDOM_STATE)
idx = rng.choice(len(X_test), size=min(1500, len(X_test)), replace=False)
Xs = X_test.iloc[idx]
model = models[selected]
if selected == "CatBoost":
    Z = prep.catboost_frame(Xs, med)
    expl = shap.TreeExplainer(model)
    sv = np.asarray(expl.shap_values(Z))
    base = float(np.ravel(expl.expected_value)[-1])
    names = list(Z.columns); grouped = pd.DataFrame(sv, columns=names)
    enc_vals, enc_names, enc_data = sv, names, Z
else:
    Z = pre.transform(Xs)
    enc_names = [n.split("__", 1)[1] for n in pre.get_feature_names_out()]
    if selected == "Logistic Regression":
        expl = shap.LinearExplainer(model, pre.transform(X_train.sample(2000, random_state=0)))
        sv = np.asarray(expl.shap_values(Z)); base = float(np.ravel(expl.expected_value)[0])
    else:
        expl = shap.TreeExplainer(model)
        sv = expl.shap_values(Z)
        sv = np.asarray(sv)
        if sv.ndim == 3: sv = sv[:, :, 1]          # RandomForest: class 1
        base = float(np.ravel(expl.expected_value)[-1])
    # group one-hot columns back to their original feature (SHAP values are additive)
    owner = []
    for n in enc_names:
        if n in NUM: owner.append(n); continue
        owner.append(max((c for c in CAT if n.startswith(c + "_")), key=len))
    grouped = pd.DataFrame(sv, columns=enc_names).T.groupby(owner).sum().T
    enc_vals, enc_data = sv, pd.DataFrame(Z, columns=enc_names)

imp = grouped.abs().mean().sort_values(ascending=False)
imp.rename("mean_abs_shap").to_csv(f"{OUT}/shap_global_importance.csv")
print("\nSHAP global importance (mean |SHAP|, top 10):"); print(imp.head(10).round(4).to_string())

top = imp.head(15)[::-1]
fig, ax = plt.subplots(figsize=(7, 5.5))
ax.barh(top.index, top.values, color="#1f77b4")
ax.set_xlabel("Mean |SHAP value| (impact on model output)")
ax.set_title(f"Global feature importance - {selected} (test set)")
fig.savefig(f"{OUT}/fig_shap_global_bar.png", dpi=200, bbox_inches="tight"); plt.close(fig)

shap.summary_plot(enc_vals, enc_data, max_display=15, show=False)
plt.title(f"SHAP summary plot - {selected}"); plt.gcf().set_size_inches(8, 6.5)
plt.savefig(f"{OUT}/fig_shap_summary_beeswarm.png", dpi=200, bbox_inches="tight"); plt.close()

# local explanation: a high-risk booking that was actually cancelled
p_s = model.predict_proba(inputs(selected, Xs))[:, 1]
cand = np.where((p_s > 0.8) & (y_test.iloc[idx].values == 1))[0]
i = int(cand[0]) if len(cand) else int(np.argmax(p_s))
raw_row = Xs.iloc[i]
exp = shap.Explanation(values=grouped.iloc[i].values, base_values=base,
                       data=np.array([raw_row[c] for c in grouped.columns], dtype=object),
                       feature_names=list(grouped.columns))
shap.plots.waterfall(exp, max_display=12, show=False)
plt.title(f"Local SHAP explanation - one booking (predicted P(cancel) = {p_s[i]:.2f})")
plt.savefig(f"{OUT}/fig_shap_waterfall_example.png", dpi=200, bbox_inches="tight"); plt.close()
print(f"\nWaterfall example: test booking index {Xs.index[i]}, P(cancel)={p_s[i]:.3f}, actual={y_test.iloc[idx].values[i]}")
print("Model output units:", "log-odds" if selected != "Random Forest" else "probability")
